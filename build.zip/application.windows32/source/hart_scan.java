import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import processing.serial.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class hart_scan extends PApplet {



Serial ard;
// Data time offset
float timeOffset;
ArrayList<PVector> data;

ArrayList<PVector> markers;

// Offset for zero point
float timePointer;
float zoom;
// Seconds per window
float spw;

// End of data times position
float saveTimeEnd;
// Mouse position in seconds
float timeMousePointer;

public void setup() {
  //size(500, 300);
  
  
  surface.setTitle("SergeiTerehov Hart Scan");
  
  spw = 5;
  timePointer = 0;
  
  data = new ArrayList();
  markers = new ArrayList();
  
  thread("updateDataLoop");
}

public void updateDataLoop() {
  while (true) {
    updateData();

    delay(5);
  }
}

public void draw() {
  if (timePointer > 0) {
    timePointer = 0;
  }

  if (spw <= 0.1f) {
    spw = 0.1f;
  } else if (spw >= 3600.0f) {
    spw = 3600.0f;
  }

  zoom = width / spw;
  timeMousePointer = 1.0f * spw * mouseX / width - timePointer;

  clear();
  
  drawGrid();
  drawMarkers();
  drawTimePointer();
  drawData();
  drawUI();
}

public void mouseWheel(MouseEvent event) {
  float e = event.getCount();

  timePointer += 0.02f * spw * e;
}

public void keyPressed() {
  if (key == 'e' || key == 'E') {
    saveTimeEnd = getTime();
    selectOutput("Файл для сохранения:", "saveFileSelected");
  }

  else if (key == 's' || key == 'S') {
    thread("resetData");
  }
  
  else if (key == ' ') {
    if (ard == null) {
      timePointer = 0;
    } else {
      timePointer = -(getTime() - 0.25f * spw);
    }
  }
  
  else if (key == 'o' || key == 'O') {
    if (ard != null) {
      ard.stop();
      ard = null;
    }

    selectInput("Выберите файл для просмотра:", "openFileSelected");
  }
  
  else if (key >= '0' && key <= '9') {
    if (ard == null) {
      ard = new Serial(this, Serial.list()[key - '0'], 115200);
      resetData();
    }
  }
  
  else if (key == 'm' || key == 'M') {
    markers.add(new PVector(timeMousePointer, mouseY));
  }
  
  else if (key == 'x' || key == 'X') {
    markers.clear();
  }
  
  else if (key == 'q' || key == 'Q') {
    if (ard != null) {
      ard.stop();
      ard = null;
    }
  }

  else if (key == '+' || key == '=') {
    spw /= 1.1f;
    timePointer -= (timePointer + timeMousePointer) * 0.1f / 1.1f;
  }
  
  else if (key == '-') {
    spw *= 1.1f;
    timePointer += (timePointer + timeMousePointer) * 0.1f;
  }
}

public void drawUI() {
  if (ard == null) {
    drawSelectDeviceUI();
  }

  drawCursorUI();
}

public void drawSelectDeviceUI() {
  String[] list = Serial.list();

  fill(130, 130, 130, data.size() > 0 ? 80 : 255);
  textSize(30);
  textAlign(LEFT, TOP);
  
  for (int i = 0; i < list.length; i++) {
    text(String.format("[%d] %s", i, list[i]), 10, i * 30);
  }
}

public void drawCursorUI() {
  stroke(100, 100, 255);
  line(
    mouseX, 0,
    mouseX, height
  );
  fill(255, 255, 255);
  textSize(30);
  textAlign(LEFT, BOTTOM);
  text(
    String.format(
      "%." + (spw > 50 ? 1 : spw > 4 ? 2 : 3) + "f сек.",
      timeMousePointer
    ),
    mouseX + 20, mouseY
  );
}

public void drawGrid() {
  stroke(30, 30, 30);

  for (float i = 0; i <= 10; i++) {
    line(
      0, i / 10 * height,
      width, i / 10 * height
    );
  }

  if (spw <= 20) {
    stroke(30, 30, 30);
  
    for (float i = -10; i <= (spw + 1) * 10; i++) {
      float offset = timePointer - PApplet.parseInt(timePointer);
      float x = (offset + i / 10.0f) * zoom;
  
      line(
        x, 0,
        x, height
      );
    }
  }
  
  stroke(80, 80, 80);
  fill(100, 100, 100);
  textAlign(LEFT, BOTTOM);
  textSize(14);
  
  float dSecond = spw > 1000 ? 60 : spw > 200 ? 10 : 1;
  
  for (float i = -1; i <= spw + 1; i += dSecond) {
    float offset = timePointer - PApplet.parseInt(timePointer);
    float x = (offset + i) * zoom;

    line(
      x, 0,
      x, height
    );
    
    text(PApplet.parseInt(-timePointer + i), x, height);
  }
}

public void drawTimePointer() {
  if (ard == null) {
    return;
  }

  stroke(90, 40, 40);
  line(
    (timePointer + getTime()) * zoom, 0,
    (timePointer + getTime()) * zoom, height
  );
  
  if (saveTimeEnd > 0) {
    stroke(40, 100, 40);
    line(
      (timePointer + saveTimeEnd) * zoom, 0,
      (timePointer + saveTimeEnd) * zoom, height
    );
  }
}

public void drawMarkers() {
  stroke(150, 90, 30);
  fill(150, 90, 30);
  textSize(20);

  for (int i = 0; i < markers.size(); i++) {
    PVector marker = markers.get(i);
    float x = (timePointer + marker.x) * zoom;

    line(
      x, 0,
      x, height
    );
    text(
      String.format("%.3f", marker.x),
      x + 10, marker.y
    );
  }
}

public void drawData() {
  stroke(255, 255, 255);
  
  for (int i = 1; i < data.size(); i++) {
    PVector a = data.get(i - 1);
    PVector b = data.get(i);
    
    float bPos = (b.x + timePointer) * zoom;
    
    if (bPos < 0 || bPos > width) {
      continue;
    }

    line(
      (a.x + timePointer) * zoom, a.y * height,
      (b.x + timePointer) * zoom, b.y * height
    );
  }
}

public float getTime() {
  return millis() / 1000.0f + timeOffset;
}

public void resetData() {
  timeOffset = -millis() / 1000.0f;
  timePointer = -getTime();

  data.clear();
  markers.clear();
}

public void updateData() {
  if (ard == null) {
    return;
  }

  if (ard.available() == 0) {
    return;
  }
  
  String src = ard.readStringUntil(10);
  
  if (src == null) {
    return;
  }
  
  float value;
  
  try {
    value = parseFloat(src.trim()) / 1023.0f;
  } catch (Exception e) {
    return;
  };
  
  float time = getTime();
  
  data.add(new PVector(time, value));
}

public void saveFileSelected(File selection) {
  if (selection == null) {
    return;
  }
  
  String path = selection.getAbsolutePath();
  
  PrintWriter file = createWriter(path);
  
  for (int i = 0; i < data.size(); i++) {
    PVector item = data.get(i);
    
    if (saveTimeEnd < item.x) {
      break;
    }

    file.println(
      String.format("%,6f", item.x) + ";" +
      String.format("%,6f", item.y)
    );
  }
  
  file.flush();
  file.close();
}

public void openFileSelected(File selected) {
  if (selected == null) {
    return;
  }
  
  String path = selected.getAbsolutePath();
  
  BufferedReader file = createReader(path);
  String line = null;
  
  data.clear();
  
  try {
    while (true) {
      line = file.readLine();
      
      if (line == null) {
        break;
      }
      
      String[] cells = split(line, ";");
      
      if (cells.length < 2) {
        continue;
      }
      
      PVector item = new PVector(
        PApplet.parseFloat(cells[0].replace(",", ".")),
        PApplet.parseFloat(cells[1].replace(",", "."))
      );
      
      data.add(item);
    }
  } catch (Exception e) {
    return;
  };
  
  if (data.size() > 0) {
    timePointer = data.get(0).x;
  }
}

  public void settings() {  fullScreen(); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "hart_scan" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
